# Список подарков

Веб-приложение на Spring Boot 3: Spring MVC, шаблоны Thymeleaf, Spring Data JPA (Hibernate) и база данных H2.
Нужны JDK 17 или новее и Maven.

## Запуск

    mvn spring-boot:run          # http://127.0.0.1:8080

Порт можно изменить: `mvn spring-boot:run -Dspring-boot.run.arguments=--server.port=9000`.

## Проверка

    mvn test                     # автоматические проверки (ApplicationTests)

## Структура

- `src/main/java/ru/kursovaya/` – код приложения:
  - `Application` – точка входа;
  - `model` – сущности JPA (`User`, `Gift`);
  - `repository` – интерфейсы Spring Data JPA;
  - `controller` – контроллеры Spring MVC (`AuthController`, `GiftController`);
  - `config` – проверка входа (`AuthInterceptor`) и его подключение (`WebConfig`);
  - `util` – хеширование паролей PBKDF2 и проверки полей формы;
- `src/main/resources/templates` – шаблоны Thymeleaf;
- `src/main/resources/static/style.css` – оформление;
- `src/main/resources/application.properties` – настройки базы данных и сервера;
- `data/` – файл базы данных H2 (создаётся при первом запуске; таблицы `users` и `gifts`).
