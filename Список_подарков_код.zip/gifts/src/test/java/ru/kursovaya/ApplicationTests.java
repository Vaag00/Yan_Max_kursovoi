package ru.kursovaya;

import static org.junit.jupiter.api.Assertions.assertEquals;

import ru.kursovaya.repository.GiftRepository;
import ru.kursovaya.repository.UserRepository;
import ru.kursovaya.util.Passwords;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * Автоматическая проверка приложения: запускает его на свободном порту
 * с временной базой данных H2 и отправляет к нему HTTP-запросы.
 */
class ApplicationTests {
    static final String URL = "/gifts";
    static final HttpClient CLIENT = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NEVER).build();
    static ConfigurableApplicationContext context;
    static String base;
    static int total = 0;
    static int failed = 0;

    /** Описание поля формы для проверок. */
    record F(String name, String label, String kind, String error, int min, int max) {
    }

    static final List<F> FIELDS = List.of(
        new F("title", "Подарок", "text", "Название подарка: от 1 до 100 символов.", 1, 100),
        new F("recipient", "Получатель", "text", "Имя получателя: от 1 до 60 символов.", 1, 60),
        new F("occasion", "Повод", "select", "Выберите повод из списка.", 0, 0),
        new F("price", "Примерная цена, ₽", "int", "Цена — целое число рублей от 0 до 10 000 000.", 0, 10000000),
        new F("bought", "Куплен", "check", "", 0, 0));

    /** «Браузер»: запоминает cookie сессии между запросами. */
    static class Browser {
        String sid = "";
    }

    @BeforeAll
    static void start() throws IOException {
        Path dir = Files.createTempDirectory("test-data");
        context = SpringApplication.run(Application.class, "--server.port=0", "--data.dir=" + dir);
        base = "http://127.0.0.1:" + context.getEnvironment().getProperty("local.server.port");
    }

    @AfterAll
    static void stop() {
        context.close();
        System.out.println();
        System.out.println("Проверок: " + total + ", успешно: " + (total - failed) + ", с ошибками: " + failed);
    }

    static String day(int shift) {
        return LocalDate.now().plusDays(shift).toString();
    }

    static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    static Map<String, String> rec(String... kv) {
        Map<String, String> m = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            m.put(kv[i], kv[i + 1]);
        }
        return m;
    }

    static String body(Map<String, String> m) {
        List<String> parts = new ArrayList<>();
        for (Map.Entry<String, String> e : m.entrySet()) {
            parts.add(enc(e.getKey()) + "=" + enc(e.getValue()));
        }
        return String.join("&", parts);
    }

    static HttpResponse<String> send(Browser b, String method, String path, String data) {
        try {
            HttpRequest.Builder r = HttpRequest.newBuilder(URI.create(base + path));
            if (!b.sid.isEmpty()) {
                r.header("Cookie", "JSESSIONID=" + b.sid);
            }
            if (method.equals("POST")) {
                r.header("Content-Type", "application/x-www-form-urlencoded");
                r.POST(HttpRequest.BodyPublishers.ofString(data));
            } else {
                r.GET();
            }
            HttpResponse<String> resp = CLIENT.send(r.build(), HttpResponse.BodyHandlers.ofString());
            for (String c : resp.headers().allValues("Set-Cookie")) {
                if (c.startsWith("JSESSIONID=")) {
                    b.sid = c.split(";")[0].substring("JSESSIONID=".length());
                }
            }
            return resp;
        } catch (IOException | InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }

    static HttpResponse<String> get(Browser b, String path) {
        return send(b, "GET", path, "");
    }

    static HttpResponse<String> post(Browser b, String path, String data) {
        return send(b, "POST", path, data);
    }

    static void check(String name, boolean ok) {
        total++;
        if (!ok) {
            failed++;
        }
        System.out.println((ok ? "  ok  " : "FAIL  ") + total + ". " + name);
    }

    static void checkOrder(String name, String html, String... tokens) {
        int last = -1;
        boolean ok = true;
        for (String t : tokens) {
            int pos = html.indexOf(t);
            ok &= pos > last;
            last = pos;
        }
        check(name, ok);
    }

    static int count(String html) {
        return html.split(URL + "/\\d+/edit", -1).length - 1;
    }

    static String redirect(HttpResponse<String> r) {
        return r.statusCode() / 100 == 3 ? r.headers().firstValue("Location").orElse("").replace(base, "") : "";
    }

    static void register(Browser b, String login, String password) {
        post(b, "/register", body(rec("login", login, "password", password, "repeat", password)));
    }

    static void login(Browser b, String login, String password) {
        post(b, "/login", body(rec("login", login, "password", password)));
    }

    @Test
    void application() {
        Browser guest = new Browser();
        Browser u1 = new Browser();
        Browser u2 = new Browser();

        // доступ без входа
        check("главная страница без входа ведёт на вход", redirect(get(guest, "/")).equals("/login"));
        check("список без входа недоступен", redirect(get(guest, URL)).equals("/login"));
        check("форма добавления без входа недоступна", redirect(get(guest, URL + "/add")).equals("/login"));
        check("страница входа открывается", get(guest, "/login").statusCode() == 200);

        // регистрация
        String r = post(guest, "/register", body(rec("login", "a!", "password", "secret1", "repeat", "secret1"))).body();
        check("некорректный логин отклоняется", r.contains("Логин: 3–30 символов"));
        r = post(guest, "/register", body(rec("login", "student", "password", "123", "repeat", "123"))).body();
        check("короткий пароль отклоняется", r.contains("не менее 6 символов"));
        r = post(guest, "/register", body(rec("login", "student", "password", "secret1", "repeat", "secret2"))).body();
        check("несовпадающие пароли отклоняются", r.contains("Пароли не совпадают"));
        check("корректная регистрация ведёт на вход",
                redirect(post(guest, "/register", body(rec("login", "student", "password", "secret1", "repeat", "secret1")))).equals("/login"));
        r = post(guest, "/register", body(rec("login", "student", "password", "secret1", "repeat", "secret1"))).body();
        check("повторная регистрация отклоняется", r.contains("уже существует"));
        String stored = context.getBean(UserRepository.class).findAll().get(0).getPassword();
        check("пароль хранится в виде хеша", stored.startsWith("pbkdf2$") && !stored.contains("secret1"));
        check("хеши одного пароля различаются из-за соли", !Passwords.hash("secret1").equals(Passwords.hash("secret1")));

        // вход
        check("неверный пароль отклоняется", post(guest, "/login", body(rec("login", "student", "password", "wrong1"))).body().contains("Неверный логин или пароль"));
        check("неизвестный логин даёт то же сообщение", post(guest, "/login", body(rec("login", "nobody", "password", "secret1"))).body().contains("Неверный логин или пароль"));
        check("попытка SQL-инъекции в логине отклоняется", post(guest, "/login", body(rec("login", "' OR '1'='1", "password", "x"))).body().contains("Неверный логин или пароль"));
        register(u2, "friend", "secret2");
        login(u2, "friend", "secret2");
        HttpResponse<String> ok = post(u1, "/login", body(rec("login", "student", "password", "secret1")));
        check("успешный вход ведёт к списку", redirect(ok).equals(URL));
        check("пустой список показывает сообщение", get(u1, URL).body().contains("Подарков пока нет."));

        // проверка полей
        Map<String, String> valid = rec("title", "Книга", "recipient", "Анна", "occasion", "День рождения", "price", "1500", "bought", "0");
        for (F f : FIELDS) {
            String bad = switch (f.kind()) {
                case "text" -> "";
                case "url" -> "ftp://example.com";
                case "date" -> "2026-13-45";
                case "int" -> "abc";
                case "select" -> "Нет такого значения";
                default -> null;
            };
            if (bad == null) {
                continue;
            }
            Map<String, String> data = new LinkedHashMap<>(valid);
            data.put(f.name(), bad);
            String page = post(u1, URL + "/add", body(data)).body();
            check("поле «" + f.label() + "»: некорректное значение отклоняется", page.contains(f.error()));
            if (f.kind().equals("int")) {
                data.put(f.name(), f.min() > 0 ? "0" : "-1");
                page = post(u1, URL + "/add", body(data)).body();
                check("поле «" + f.label() + "»: значение вне диапазона отклоняется", page.contains(f.error()));
            }
        }
        check("после ошибок запись не создана", count(get(u1, URL).body()) == 0);

        // добавление
        List<Map<String, String>> samples = List.of(
            rec("title", "Книга", "recipient", "Анна", "occasion", "День рождения", "price", "1500", "bought", "0"),
            rec("title", "Часы", "recipient", "Борис", "occasion", "Новый год", "price", "7000", "bought", "0"));
        for (Map<String, String> s : samples) {
            check("запись №" + (samples.indexOf(s) + 1) + " добавляется", redirect(post(u1, URL + "/add", body(s))).equals(URL));
        }
        String list = get(u1, URL).body();
        check("все добавленные записи видны в списке", count(list) == samples.size());
        checkOrder("записи отсортированы в нужном порядке", list, "<td>Часы</td>", "<td>Книга</td>");

        // фильтр
        String filtered = get(u1, URL + "?occasion=" + enc("День рождения")).body();
        check("фильтр оставляет только подходящие записи", filtered.contains("<td>Книга</td>") && !filtered.contains("<td>Часы</td>"));
        String unknown = get(u1, URL + "?occasion=" + enc("Неизвестное значение")).body();
        check("неизвестное значение фильтра игнорируется", unknown.contains("<td>Книга</td>") && unknown.contains("<td>Часы</td>"));

        // редактирование
        String edit = get(u1, URL + "/1/edit").body();
        check("форма редактирования заполнена текущими данными", edit.contains("value=\"" + samples.get(0).get("title") + "\"")
                || edit.contains("selected") || edit.contains("checked"));
        Map<String, String> changed = new LinkedHashMap<>(samples.get(0));
        changed.put("price", "2000");
        check("изменённая запись сохраняется", redirect(post(u1, URL + "/1/edit", body(changed))).equals(URL));
        check("изменения видны в списке", get(u1, URL).body().contains("<td>2000</td>"));
        changed.put("price", "");
        check("некорректная правка не сохраняется", !redirect(post(u1, URL + "/1/edit", body(changed))).equals(URL)
                && get(u1, URL).body().contains("<td>2000</td>"));

        // отметка записи
        post(u1, URL + "/2/toggle", "");
        String afterToggle = get(u1, URL).body();
        check("кнопка «Отметить» меняет значение", afterToggle.contains("<td>Куплен</td>"));
        checkOrder("после отметки порядок записей изменился", afterToggle, "<td>Книга</td>", "<td>Часы</td>");
        post(u1, URL + "/2/toggle", "");
        check("повторная отметка возвращает значение", !get(u1, URL).body().contains("<td>Куплен</td>"));
        post(u1, URL + "/2/toggle", "");
        post(u2, URL + "/2/toggle", "");
        check("чужую запись отметить нельзя", get(u2, URL).body().contains("<td>Куплен</td>") == false);

        // разграничение доступа
        check("чужие записи не видны в списке", count(get(u2, URL).body()) == 0);
        check("чужую запись нельзя открыть для правки", get(u2, URL + "/1/edit").statusCode() == 404);
        check("чужую запись нельзя изменить", post(u2, URL + "/1/edit", body(changed)).statusCode() == 404);
        check("чужую запись нельзя удалить", post(u2, URL + "/1/delete", "").statusCode() == 404);
        check("после попыток запись осталась у владельца", count(get(u1, URL).body()) == samples.size());

        // удаление
        check("удаление методом GET запрещено (405)", get(u1, URL + "/1/delete").statusCode() == 405);
        check("запись удаляется методом POST", redirect(post(u1, URL + "/1/delete", "")).equals(URL));
        check("удалённая запись исчезла из списка", count(get(u1, URL).body()) == samples.size() - 1);
        check("несуществующая запись даёт ошибку 404", get(u1, URL + "/999/edit").statusCode() == 404);


        // экранирование специальных символов HTML
        Map<String, String> xss = new LinkedHashMap<>(valid);
        xss.put("title", "<b>x</b>");
        post(u1, URL + "/add", body(xss));
        String xssList = get(u1, URL).body();
        check("специальные символы HTML экранируются", xssList.contains("&lt;b&gt;x&lt;/b&gt;") && !xssList.contains("<b>x</b>"));
        post(u1, URL + "/3/delete", "");

        // прочее
        check("таблица стилей отдаётся браузеру", get(u1, "/style.css").statusCode() == 200);
        check("несуществующая страница даёт ошибку 404", get(u1, "/no-such-page").statusCode() == 404);
        check("данные сохраняются в базе данных",
                context.getBean(GiftRepository.class).count() == samples.size() - 1);
        get(u1, "/logout");
        check("выход из системы закрывает доступ", redirect(get(u1, URL)).equals("/login"));

        assertEquals(0, failed, "Есть непройденные проверки");
    }
}
