package ru.kursovaya.controller;

import ru.kursovaya.config.AuthInterceptor;
import ru.kursovaya.model.Gift;
import ru.kursovaya.repository.GiftRepository;
import ru.kursovaya.repository.UserRepository;
import ru.kursovaya.util.Validation;
import jakarta.servlet.http.HttpSession;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

/** Работа с записями: список с фильтром, добавление, правка и удаление. */
@Controller
@RequestMapping("/gifts")
public class GiftController {
    private static final Comparator<Gift> ORDER = Comparator.comparing(Gift::isBought)
            .thenComparing(Gift::getId, Comparator.reverseOrder());

    private final GiftRepository gifts;
    private final UserRepository users;

    public GiftController(GiftRepository gifts, UserRepository users) {
        this.gifts = gifts;
        this.users = users;
    }

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String occasion, HttpSession session, Model model) {
        Long userId = AuthInterceptor.userId(session);
        List<Gift> items = Gift.OCCASION_OPTIONS.contains(occasion)
                ? gifts.findByUserIdAndOccasion(userId, occasion)
                : gifts.findByUserId(userId);
        items.sort(ORDER);
        model.addAttribute("items", items);
        model.addAttribute("selected", occasion);
        model.addAttribute("filterOptions", Gift.OCCASION_OPTIONS);
        return "gifts";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("title", "");
        form.put("recipient", "");
        form.put("occasion", Gift.OCCASION_OPTIONS.get(0));
        form.put("price", "");
        form.put("bought", "0");
        return showForm(model, form, "Новый подарок", "/gifts/add", false);
    }

    @PostMapping("/add")
    public String add(@RequestParam Map<String, String> params, HttpSession session, Model model) {
        Map<String, String> form = readForm(params);
        String error = validate(form);
        if (error != null) {
            model.addAttribute("error", error);
            return showForm(model, form, "Новый подарок", "/gifts/add", false);
        }
        Gift item = new Gift();
        item.setUser(users.getReferenceById(AuthInterceptor.userId(session)));
        fill(item, form);
        gifts.save(item);
        return "redirect:/gifts";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, HttpSession session, Model model) {
        Gift item = findOwn(id, session);
        return showForm(model, toForm(item), "Редактирование подарка", "/gifts/" + id + "/edit", true);
    }

    @PostMapping("/{id}/edit")
    public String edit(@PathVariable Long id, @RequestParam Map<String, String> params,
                       HttpSession session, Model model) {
        Gift item = findOwn(id, session);
        Map<String, String> form = readForm(params);
        String error = validate(form);
        if (error != null) {
            model.addAttribute("error", error);
            return showForm(model, form, "Редактирование подарка", "/gifts/" + id + "/edit", true);
        }
        fill(item, form);
        gifts.save(item);
        return "redirect:/gifts";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, HttpSession session) {
        gifts.delete(findOwn(id, session));
        return "redirect:/gifts";
    }

    /** Переключает отметку записи (статус, «куплен», «возвращён»). */
    @PostMapping("/{id}/toggle")
    public String toggle(@PathVariable Long id, HttpSession session) {
        Gift item = findOwn(id, session);
        item.setBought(!item.isBought());
        gifts.save(item);
        return "redirect:/gifts";
    }

    /** Загружает запись по номеру, только если она принадлежит текущему пользователю. */
    private Gift findOwn(Long id, HttpSession session) {
        return gifts.findByIdAndUserId(id, AuthInterceptor.userId(session))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private String showForm(Model model, Map<String, String> form, String title, String action, boolean edit) {
        model.addAttribute("form", form);
        model.addAttribute("title", title);
        model.addAttribute("action", "/gifts");
        model.addAttribute("formAction", action);
        model.addAttribute("edit", edit);
        model.addAttribute("occasionOptions", Gift.OCCASION_OPTIONS);
        return "form";
    }

    /** Читает значения полей из запроса. */
    private Map<String, String> readForm(Map<String, String> params) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("title", params.getOrDefault("title", "").trim());
        form.put("recipient", params.getOrDefault("recipient", "").trim());
        form.put("occasion", params.getOrDefault("occasion", Gift.OCCASION_OPTIONS.get(0)).trim());
        form.put("price", params.getOrDefault("price", "").trim());
        form.put("bought", "1".equals(params.get("bought")) ? "1" : "0");
        return form;
    }

    /** Общая для добавления и редактирования проверка полей формы. */
    private String validate(Map<String, String> form) {
        String v;
        v = form.get("title");
        if (v.length() < 1 || v.length() > 100) {
            return "Название подарка: от 1 до 100 символов.";
        }
        v = form.get("recipient");
        if (v.length() < 1 || v.length() > 60) {
            return "Имя получателя: от 1 до 60 символов.";
        }
        v = form.get("occasion");
        if (!Gift.OCCASION_OPTIONS.contains(v)) {
            return "Выберите повод из списка.";
        }
        v = form.get("price");
        if (!Validation.isInt(v, 0, 10000000)) {
            return "Цена — целое число рублей от 0 до 10 000 000.";
        }
        return null;
    }

    private void fill(Gift item, Map<String, String> form) {
        item.setTitle(form.get("title"));
        item.setRecipient(form.get("recipient"));
        item.setOccasion(form.get("occasion"));
        item.setPrice(Integer.parseInt(form.get("price")));
        item.setBought("1".equals(form.get("bought")));
    }

    private Map<String, String> toForm(Gift item) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("title", item.getTitle());
        form.put("recipient", item.getRecipient());
        form.put("occasion", item.getOccasion());
        form.put("price", String.valueOf(item.getPrice()));
        form.put("bought", item.isBought() ? "1" : "0");
        return form;
    }
}
