package ru.kursovaya.util;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/** Вспомогательные проверки значений полей формы. */
public final class Validation {
    private Validation() {
    }

    public static boolean isDate(String v) {
        try {
            LocalDate.parse(v);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    /** Целое число из 1–9 цифр в заданных границах. */
    public static boolean isInt(String v, int min, int max) {
        if (!v.matches("[0-9]{1,9}")) {
            return false;
        }
        int number = Integer.parseInt(v);
        return number >= min && number <= max;
    }

    public static boolean isWebAddress(String v) {
        try {
            URI uri = new URI(v);
            return ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))
                    && uri.getHost() != null;
        } catch (URISyntaxException e) {
            return false;
        }
    }
}
