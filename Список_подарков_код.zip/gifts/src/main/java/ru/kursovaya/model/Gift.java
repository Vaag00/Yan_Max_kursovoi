package ru.kursovaya.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

/** Запись пользователя: хранится в таблице «gifts» и принадлежит одному пользователю. */
@Entity
@Table(name = "gifts")
public class Gift {
    public static final DateTimeFormatter RU_DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");
    public static final List<String> OCCASION_OPTIONS = List.of("День рождения", "Новый год", "8 Марта", "23 Февраля", "Другое");
    public static final List<String> BOUGHT_LABELS = List.of("Не куплен", "Куплен");

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "user_id")
    private User user;

    @Column(name = "title", nullable = false, length = 100)
    private String title;

    @Column(name = "recipient", nullable = false, length = 60)
    private String recipient;

    @Column(name = "occasion", nullable = false, length = 50)
    private String occasion;

    @Column(name = "price", nullable = false)
    private int price;

    @Column(name = "is_bought", nullable = false)
    private boolean bought;

    public Long getId() {
        return id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getRecipient() {
        return recipient;
    }

    public void setRecipient(String recipient) {
        this.recipient = recipient;
    }

    public String getOccasion() {
        return occasion;
    }

    public void setOccasion(String occasion) {
        this.occasion = occasion;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public boolean isBought() {
        return bought;
    }

    public void setBought(boolean bought) {
        this.bought = bought;
    }

    /** Текст статуса для вывода в таблице. */
    public String getBoughtText() {
        return BOUGHT_LABELS.get(bought ? 1 : 0);
    }
}
