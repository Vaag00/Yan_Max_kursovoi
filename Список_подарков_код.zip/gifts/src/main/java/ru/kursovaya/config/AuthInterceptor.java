package ru.kursovaya.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.servlet.HandlerInterceptor;

/** Пропускает к страницам с данными только вошедших пользователей. */
public class AuthInterceptor implements HandlerInterceptor {
    public static final String USER_ID = "userId";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response,
                             Object handler) throws Exception {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute(USER_ID) == null) {
            response.sendRedirect("/login");
            return false;
        }
        return true;
    }

    /** Номер текущего пользователя из сессии. */
    public static Long userId(HttpSession session) {
        return (Long) session.getAttribute(USER_ID);
    }
}
