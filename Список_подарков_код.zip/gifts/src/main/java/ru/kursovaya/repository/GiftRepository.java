package ru.kursovaya.repository;

import ru.kursovaya.model.Gift;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** Доступ к таблице «gifts»: запросы строятся Spring Data JPA по именам методов. */
public interface GiftRepository extends JpaRepository<Gift, Long> {
    List<Gift> findByUserId(Long userId);

    List<Gift> findByUserIdAndOccasion(Long userId, String occasion);

    Optional<Gift> findByIdAndUserId(Long id, Long userId);
}
