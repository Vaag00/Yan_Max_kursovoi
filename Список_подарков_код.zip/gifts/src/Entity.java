import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

/** Описание сущности приложения «Список подарков»: таблица, адреса, надписи и поля. */
public final class Entity {
    public static final String TABLE = "gifts";
    public static final String URL = "/gifts";
    public static final String LIST_TEMPLATE = "gifts.html";
    public static final String LIST_TITLE = "Мои подарки";
    public static final String NEW_TITLE = "Новый подарок";
    public static final String EDIT_TITLE = "Редактирование подарка";
    public static final String EMPTY_TEXT = "Подарков пока нет.";
    public static final String DELETE_QUESTION = "Удалить подарок?";
    /** Поле, по которому работает фильтр списка (пустая строка – фильтра нет). */
    public static final String FILTER = "occasion";
    public static final String FILTER_LABEL = "Повод";
    public static final String FILTER_ALL = "Все поводы";
    /** Поле, значение которого переключается кнопкой «Отметить» (может быть пустым). */
    public static final String TOGGLE = "is_bought";
    public static final DateTimeFormatter RU_DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public static final List<Field> FIELDS = List.of(
            new Field("title", "Подарок", "Подарок", "text",
                    List.of(), 1, 100, "Название подарка: от 1 до 100 символов.", true),
            new Field("recipient", "Получатель", "Получатель", "text",
                    List.of(), 1, 60, "Имя получателя: от 1 до 60 символов.", true),
            new Field("occasion", "Повод", "Повод", "select",
                    List.of("День рождения", "Новый год", "8 Марта", "23 Февраля", "Другое"), 0, 0, "Выберите повод из списка.", true),
            new Field("price", "Примерная цена, ₽", "Цена, ₽", "int",
                    List.of(), 0, 10000000, "Цена — целое число рублей от 0 до 10 000 000.", true),
            new Field("is_bought", "Куплен", "Статус", "check",
                    List.of("Не куплен", "Куплен"), 0, 0, "", true));

    private Entity() {
    }

    /** Названия столбцов таблицы: номер, владелец и поля записи. */
    public static List<String> columns() {
        return List.of("id", "user_id", "title", "recipient", "occasion", "price", "is_bought");
    }

    /** Поле по имени или null. */
    public static Field field(String name) {
        for (Field f : FIELDS) {
            if (f.name().equals(name)) {
                return f;
            }
        }
        return null;
    }

    private static long id(Map<String, String> row) {
        return Long.parseLong(row.get("id"));
    }

    /** Порядок записей в списке. */
    public static int compare(Map<String, String> a, Map<String, String> b) {
        int c = a.get("is_bought").compareTo(b.get("is_bought"));
        return c != 0 ? c : Long.compare(id(b), id(a));
    }
}
