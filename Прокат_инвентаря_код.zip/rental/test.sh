#!/bin/sh
mkdir -p out
javac -encoding UTF-8 -cp lib/h2-2.2.224.jar -d out src/*.java test/*.java && java -Dfile.encoding=UTF-8 -Dstdout.encoding=UTF-8 -cp out:lib/h2-2.2.224.jar Tests
