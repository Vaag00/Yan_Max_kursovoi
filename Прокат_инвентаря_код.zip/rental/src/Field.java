import java.util.List;

/** Описание одного поля записи: имя, подписи, тип и правила проверки. */
public record Field(String name, String label, String header, String kind,
                    List<String> options, int min, int max, String error,
                    boolean onAdd) {
    // kind: text, url, date, int, select, check
}
