package ru.kursovaya.controller;

import ru.kursovaya.config.AuthInterceptor;
import ru.kursovaya.model.User;
import ru.kursovaya.repository.UserRepository;
import ru.kursovaya.util.Passwords;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import java.util.regex.Pattern;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Регистрация, вход и выход пользователей. */
@Controller
public class AuthController {
    private static final Pattern LOGIN = Pattern.compile("[A-Za-z0-9_]{3,30}");

    private final UserRepository users;

    public AuthController(UserRepository users) {
        this.users = users;
    }

    @GetMapping("/")
    public String index(HttpSession session) {
        return session.getAttribute(AuthInterceptor.USER_ID) != null ? "redirect:/items" : "redirect:/login";
    }

    @GetMapping("/register")
    public String registerForm() {
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam(defaultValue = "") String login,
                           @RequestParam(defaultValue = "") String password,
                           @RequestParam(defaultValue = "") String repeat,
                           Model model, RedirectAttributes redirect) {
        login = login.trim();
        String error = null;
        if (!LOGIN.matcher(login).matches()) {
            error = "Логин: 3–30 символов, латиница, цифры и «_».";
        } else if (password.length() < 6) {
            error = "Пароль должен содержать не менее 6 символов.";
        } else if (!password.equals(repeat)) {
            error = "Пароли не совпадают.";
        } else if (users.existsByLogin(login)) {
            error = "Пользователь с таким логином уже существует.";
        }
        if (error == null) {
            try {
                users.save(new User(login, Passwords.hash(password)));
            } catch (DataIntegrityViolationException e) {
                error = "Пользователь с таким логином уже существует.";
            }
        }
        if (error != null) {
            model.addAttribute("error", error);
            model.addAttribute("login", login);
            return "register";
        }
        redirect.addFlashAttribute("message", "Регистрация прошла успешно. Войдите в систему.");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam(defaultValue = "") String login,
                        @RequestParam(defaultValue = "") String password,
                        HttpServletRequest request, Model model) {
        Optional<User> found = users.findByLogin(login.trim());
        if (found.isEmpty() || !Passwords.check(password, found.get().getPassword())) {
            model.addAttribute("error", "Неверный логин или пароль.");
            model.addAttribute("login", login);
            return "login";
        }
        HttpSession session = request.getSession();
        request.changeSessionId();
        session.setAttribute(AuthInterceptor.USER_ID, found.get().getId());
        session.setAttribute("login", found.get().getLogin());
        return "redirect:/items";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
