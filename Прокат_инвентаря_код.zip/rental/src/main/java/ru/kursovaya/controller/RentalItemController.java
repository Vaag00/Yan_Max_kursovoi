package ru.kursovaya.controller;

import ru.kursovaya.config.AuthInterceptor;
import ru.kursovaya.model.RentalItem;
import ru.kursovaya.repository.RentalItemRepository;
import ru.kursovaya.repository.UserRepository;
import ru.kursovaya.util.Validation;
import jakarta.servlet.http.HttpSession;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.server.ResponseStatusException;

/** Работа с записями: список с фильтром, добавление, правка и удаление. */
@Controller
@RequestMapping("/items")
public class RentalItemController {
    private static final Comparator<RentalItem> ORDER = Comparator.comparing(RentalItem::getId, Comparator.reverseOrder());

    private final RentalItemRepository rentalItems;
    private final UserRepository users;

    public RentalItemController(RentalItemRepository rentalItems, UserRepository users) {
        this.rentalItems = rentalItems;
        this.users = users;
    }

    @GetMapping
    public String list(@RequestParam(defaultValue = "") String itemType, HttpSession session, Model model) {
        Long userId = AuthInterceptor.userId(session);
        List<RentalItem> items = RentalItem.ITEM_TYPE_OPTIONS.contains(itemType)
                ? rentalItems.findByUserIdAndItemType(userId, itemType)
                : rentalItems.findByUserId(userId);
        items.sort(ORDER);
        model.addAttribute("items", items);
        model.addAttribute("selected", itemType);
        model.addAttribute("filterOptions", RentalItem.ITEM_TYPE_OPTIONS);
        return "items";
    }

    @GetMapping("/add")
    public String addForm(Model model) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("name", "");
        form.put("itemType", RentalItem.ITEM_TYPE_OPTIONS.get(0));
        form.put("pricePerHour", "");
        form.put("status", RentalItem.STATUS_OPTIONS.get(0));
        return showForm(model, form, "Новый инвентарь", "/items/add", false);
    }

    @PostMapping("/add")
    public String add(@RequestParam Map<String, String> params, HttpSession session, Model model) {
        Map<String, String> form = readForm(params);
        String error = validate(form);
        if (error != null) {
            model.addAttribute("error", error);
            return showForm(model, form, "Новый инвентарь", "/items/add", false);
        }
        RentalItem item = new RentalItem();
        item.setUser(users.getReferenceById(AuthInterceptor.userId(session)));
        fill(item, form);
        rentalItems.save(item);
        return "redirect:/items";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable Long id, HttpSession session, Model model) {
        RentalItem item = findOwn(id, session);
        return showForm(model, toForm(item), "Редактирование инвентаря", "/items/" + id + "/edit", true);
    }

    @PostMapping("/{id}/edit")
    public String edit(@PathVariable Long id, @RequestParam Map<String, String> params,
                       HttpSession session, Model model) {
        RentalItem item = findOwn(id, session);
        Map<String, String> form = readForm(params);
        String error = validate(form);
        if (error != null) {
            model.addAttribute("error", error);
            return showForm(model, form, "Редактирование инвентаря", "/items/" + id + "/edit", true);
        }
        fill(item, form);
        rentalItems.save(item);
        return "redirect:/items";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id, HttpSession session) {
        rentalItems.delete(findOwn(id, session));
        return "redirect:/items";
    }

    /** Загружает запись по номеру, только если она принадлежит текущему пользователю. */
    private RentalItem findOwn(Long id, HttpSession session) {
        return rentalItems.findByIdAndUserId(id, AuthInterceptor.userId(session))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    private String showForm(Model model, Map<String, String> form, String title, String action, boolean edit) {
        model.addAttribute("form", form);
        model.addAttribute("title", title);
        model.addAttribute("action", "/items");
        model.addAttribute("formAction", action);
        model.addAttribute("edit", edit);
        model.addAttribute("itemTypeOptions", RentalItem.ITEM_TYPE_OPTIONS);
        model.addAttribute("statusOptions", RentalItem.STATUS_OPTIONS);
        return "form";
    }

    /** Читает значения полей из запроса. */
    private Map<String, String> readForm(Map<String, String> params) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("name", params.getOrDefault("name", "").trim());
        form.put("itemType", params.getOrDefault("itemType", RentalItem.ITEM_TYPE_OPTIONS.get(0)).trim());
        form.put("pricePerHour", params.getOrDefault("pricePerHour", "").trim());
        form.put("status", params.getOrDefault("status", RentalItem.STATUS_OPTIONS.get(0)).trim());
        return form;
    }

    /** Общая для добавления и редактирования проверка полей формы. */
    private String validate(Map<String, String> form) {
        String v;
        v = form.get("name");
        if (v.length() < 1 || v.length() > 100) {
            return "Название: от 1 до 100 символов.";
        }
        v = form.get("itemType");
        if (!RentalItem.ITEM_TYPE_OPTIONS.contains(v)) {
            return "Выберите вид инвентаря из списка.";
        }
        v = form.get("pricePerHour");
        if (!Validation.isInt(v, 1, 100000)) {
            return "Цена за час — целое число рублей от 1 до 100 000.";
        }
        v = form.get("status");
        if (!RentalItem.STATUS_OPTIONS.contains(v)) {
            return "Выберите статус из списка.";
        }
        return null;
    }

    private void fill(RentalItem item, Map<String, String> form) {
        item.setName(form.get("name"));
        item.setItemType(form.get("itemType"));
        item.setPricePerHour(Integer.parseInt(form.get("pricePerHour")));
        item.setStatus(form.get("status"));
    }

    private Map<String, String> toForm(RentalItem item) {
        Map<String, String> form = new LinkedHashMap<>();
        form.put("name", item.getName());
        form.put("itemType", item.getItemType());
        form.put("pricePerHour", String.valueOf(item.getPricePerHour()));
        form.put("status", item.getStatus());
        return form;
    }
}
