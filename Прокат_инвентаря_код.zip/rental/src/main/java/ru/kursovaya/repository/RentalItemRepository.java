package ru.kursovaya.repository;

import ru.kursovaya.model.RentalItem;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

/** Доступ к таблице «rental_items»: запросы строятся Spring Data JPA по именам методов. */
public interface RentalItemRepository extends JpaRepository<RentalItem, Long> {
    List<RentalItem> findByUserId(Long userId);

    List<RentalItem> findByUserIdAndItemType(Long userId, String itemType);

    Optional<RentalItem> findByIdAndUserId(Long id, Long userId);
}
