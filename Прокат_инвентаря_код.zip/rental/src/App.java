import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import java.io.IOException;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Обработчик всех запросов: маршрутизация, регистрация, вход и работа с записями. */
public class App implements HttpHandler {
    private static final Pattern LOGIN = Pattern.compile("[A-Za-z0-9_]{3,30}");
    private static final Pattern ITEM = Pattern.compile(Entity.URL + "/(\\d+)/(edit|delete|toggle)");
    private static final SecureRandom RANDOM = new SecureRandom();

    private final Table users = new Table("users", List.of("id", "login", "password"));
    private final Table items = new Table(Entity.TABLE, Entity.columns());
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    /** Ошибка «не найдено»: адрес не существует или запись чужая. */
    private static class NotFound extends RuntimeException {
    }

    /** Результат проверки формы: значения полей либо текст ошибки. */
    private record Form(Map<String, String> values, String error) {
    }

    // ------------------------------------------------------------ запрос

    /** Данные одного запроса: адрес, параметры, форма, сессия и текущий пользователь. */
    private final class Ctx {
        final HttpExchange ex;
        final String method;
        final String path;
        final Map<String, String> query;
        final Map<String, String> form;
        String sid;
        Session session;
        boolean newCookie;
        Map<String, String> user;

        Ctx(HttpExchange ex) throws IOException {
            this.ex = ex;
            this.method = ex.getRequestMethod();
            URI uri = ex.getRequestURI();
            this.path = uri.getPath();
            this.query = parse(uri.getRawQuery());
            String body = new String(ex.getRequestBody().readNBytes(1_000_000), StandardCharsets.UTF_8);
            this.form = parse(body);
            this.sid = readCookie("sid");
            this.session = sid == null ? null : sessions.get(sid);
            if (session == null) {
                startSession(null);
            }
            if (session.userId != null) {
                this.user = users.find(session.userId);
            }
        }

        private String readCookie(String name) {
            String header = ex.getRequestHeaders().getFirst("Cookie");
            if (header != null) {
                for (String part : header.split(";")) {
                    String[] kv = part.trim().split("=", 2);
                    if (kv.length == 2 && kv[0].equals(name)) {
                        return kv[1];
                    }
                }
            }
            return null;
        }

        /** Создаёт новую сессию (старая при этом забывается). */
        void startSession(Long userId) {
            if (sid != null) {
                sessions.remove(sid);
            }
            byte[] token = new byte[32];
            RANDOM.nextBytes(token);
            sid = Base64.getUrlEncoder().withoutPadding().encodeToString(token);
            session = new Session();
            session.userId = userId;
            sessions.put(sid, session);
            newCookie = true;
        }

        boolean isPost() {
            return method.equals("POST");
        }

        String form(String name) {
            return form.getOrDefault(name, "");
        }

        void flash(String text, String kind) {
            session.flashes.add(new String[] {kind, text});
        }

        String userId() {
            return user.get("id");
        }

        /** Для неавторизованного пользователя выполняет перенаправление на вход. */
        boolean requireLogin() throws IOException {
            if (user == null) {
                redirect("/login");
                return false;
            }
            return true;
        }

        void redirect(String location) throws IOException {
            ex.getResponseHeaders().set("Location", location);
            send(303, "text/plain; charset=utf-8", new byte[0]);
        }

        void text(int code, String text) throws IOException {
            send(code, "text/plain; charset=utf-8", text.getBytes(StandardCharsets.UTF_8));
        }

        /** Выводит страницу, вложенную в базовый шаблон base.html. */
        void page(int code, String title, String content) throws IOException {
            StringBuilder flashes = new StringBuilder();
            for (String[] f : session.flashes) {
                flashes.append("<div class=\"flash ").append(Html.esc(f[0])).append("\">")
                        .append(Html.esc(f[1])).append("</div>\n");
            }
            session.flashes.clear();
            String nav = user == null ? "" : "<nav>\n      <span class=\"user\">" + Html.esc(user.get("login"))
                    + "</span>\n      <a href=\"/logout\">Выйти</a>\n    </nav>";
            String html = Html.render("base.html", Map.of("title", title, "nav", nav,
                    "flashes", flashes.toString(), "content", content));
            send(code, "text/html; charset=utf-8", html.getBytes(StandardCharsets.UTF_8));
        }

        void page(String title, String content) throws IOException {
            page(200, title, content);
        }

        void send(int code, String type, byte[] body) throws IOException {
            ex.getResponseHeaders().set("Content-Type", type);
            ex.getResponseHeaders().set("Cache-Control", "no-store");
            if (newCookie) {
                ex.getResponseHeaders().add("Set-Cookie", "sid=" + sid + "; Path=/; HttpOnly; SameSite=Lax");
            }
            ex.sendResponseHeaders(code, body.length == 0 ? -1 : body.length);
            if (body.length > 0) {
                ex.getResponseBody().write(body);
            }
            ex.close();
        }
    }

    private static Map<String, String> parse(String raw) {
        Map<String, String> result = new LinkedHashMap<>();
        if (raw == null || raw.isEmpty()) {
            return result;
        }
        for (String pair : raw.split("&")) {
            String[] kv = pair.split("=", 2);
            result.put(URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                    kv.length == 2 ? URLDecoder.decode(kv[1], StandardCharsets.UTF_8) : "");
        }
        return result;
    }

    // ------------------------------------------------------- маршрутизация

    @Override
    public void handle(HttpExchange ex) throws IOException {
        Ctx c = new Ctx(ex);
        try {
            route(c);
        } catch (NotFound e) {
            c.page(404, "Не найдено", "<section class=\"card narrow\"><h1>Страница не найдена</h1>"
                    + "<p class=\"hint\"><a href=\"/\">На главную</a></p></section>");
        } catch (RuntimeException e) {
            e.printStackTrace();
            c.text(500, "Внутренняя ошибка сервера");
        }
    }

    private void route(Ctx c) throws IOException {
        if (c.path.startsWith("/static/")) {
            sendStatic(c, c.path.substring("/static/".length()));
            return;
        }
        switch (c.path) {
            case "/" -> c.redirect(c.user != null ? Entity.URL : "/login");
            case "/register" -> register(c);
            case "/login" -> login(c);
            case "/logout" -> {
                c.startSession(null);
                c.redirect("/login");
            }
            case Entity.URL -> list(c);
            case Entity.URL + "/add" -> add(c);
            default -> {
                Matcher m = ITEM.matcher(c.path);
                if (!m.matches()) {
                    throw new NotFound();
                }
                long id = Long.parseLong(m.group(1));
                switch (m.group(2)) {
                    case "edit" -> edit(c, id);
                    case "delete" -> delete(c, id);
                    default -> toggle(c, id);
                }
            }
        }
    }

    private void sendStatic(Ctx c, String name) throws IOException {
        if (!name.matches("[A-Za-z0-9_.-]+") || name.contains("..")) {
            throw new NotFound();
        }
        Path file = Path.of("static", name);
        if (!Files.isRegularFile(file)) {
            throw new NotFound();
        }
        c.send(200, "text/css; charset=utf-8", Files.readAllBytes(file));
    }

    // ------------------------------------------------- регистрация и вход

    private synchronized boolean createUser(String login, String password) {
        if (!users.select("\"login\" = ?", login).isEmpty()) {
            return false;
        }
        users.insert(Map.of("login", login, "password", Passwords.hash(password)));
        return true;
    }

    private void register(Ctx c) throws IOException {
        if (c.isPost()) {
            String login = c.form("login").trim();
            String password = c.form("password");
            String error = null;
            if (!LOGIN.matcher(login).matches()) {
                error = "Логин: 3–30 символов, латиница, цифры и «_».";
            } else if (password.length() < 6) {
                error = "Пароль должен содержать не менее 6 символов.";
            } else if (!password.equals(c.form("repeat"))) {
                error = "Пароли не совпадают.";
            } else if (!createUser(login, password)) {
                error = "Пользователь с таким логином уже существует.";
            }
            if (error == null) {
                c.flash("Регистрация прошла успешно. Войдите в систему.", "message");
                c.redirect("/login");
                return;
            }
            c.flash(error, "error");
        }
        c.page("Регистрация", Html.render("register.html", Map.of("login", c.form("login"))));
    }

    private void login(Ctx c) throws IOException {
        if (c.isPost()) {
            String login = c.form("login").trim();
            List<Map<String, String>> users1 = users.select("\"login\" = ?", login);
            Map<String, String> found = users1.isEmpty() ? null : users1.get(0);
            if (found == null || !Passwords.check(c.form("password"), found.get("password"))) {
                c.flash("Неверный логин или пароль.", "error");
            } else {
                c.startSession(Long.parseLong(found.get("id")));
                c.redirect(Entity.URL);
                return;
            }
        }
        c.page("Вход", Html.render("login.html", Map.of("login", c.form("login"))));
    }

    // ------------------------------------------------------ список записей

    private void list(Ctx c) throws IOException {
        if (!c.requireLogin()) {
            return;
        }
        String selected = c.query.getOrDefault(Entity.FILTER, "");
        Field filterField = Entity.field(Entity.FILTER);
        boolean filtered = filterField != null && filterField.options().contains(selected);
        List<Map<String, String>> rows = filtered
                ? items.select("\"user_id\" = ? AND \"" + Entity.FILTER + "\" = ?", c.userId(), selected)
                : items.select("\"user_id\" = ?", c.userId());
        rows.sort(Entity::compare);

        String filter = "";
        if (filterField != null) {
            StringBuilder options = new StringBuilder();
            for (String o : filterField.options()) {
                options.append("<option value=\"").append(Html.esc(o)).append("\"")
                        .append(o.equals(selected) ? " selected" : "").append(">")
                        .append(Html.esc(o)).append("</option>\n");
            }
            filter = Html.render("filter.html", Map.of("label", Entity.FILTER_LABEL,
                    "name", Entity.FILTER, "all", Entity.FILTER_ALL, "options", options.toString()));
        }
        String table;
        if (rows.isEmpty()) {
            table = "<p class=\"empty\">" + Html.esc(Entity.EMPTY_TEXT) + "</p>";
        } else {
            StringBuilder headers = new StringBuilder();
            for (Field f : Entity.FIELDS) {
                headers.append("<th>").append(Html.esc(f.header())).append("</th>");
            }
            StringBuilder body = new StringBuilder();
            for (Map<String, String> row : rows) {
                body.append(rowHtml(row));
            }
            table = Html.render("table.html", Map.of("headers", headers.toString(), "rows", body.toString()));
        }
        c.page(Entity.LIST_TITLE, Html.render(Entity.LIST_TEMPLATE, Map.of("title", Entity.LIST_TITLE,
                "addUrl", Entity.URL + "/add", "filter", filter, "table", table)));
    }

    /** Формирует строку таблицы по шаблону row.html. */
    private String rowHtml(Map<String, String> row) {
        StringBuilder cells = new StringBuilder();
        for (Field f : Entity.FIELDS) {
            String value = row.get(f.name());
            String shown = switch (f.kind()) {
                case "date" -> Html.esc(LocalDate.parse(value).format(Entity.RU_DATE));
                case "check" -> Html.esc(f.options().get(value.equals("1") ? 1 : 0));
                case "url" -> "<a href=\"" + Html.esc(value) + "\" target=\"_blank\" rel=\"noopener noreferrer\">"
                        + Html.esc(value) + "</a>";
                default -> Html.esc(value);
            };
            cells.append("<td>").append(shown).append("</td>\n        ");
        }
        String base = Entity.URL + "/" + row.get("id");
        String toggle = Entity.TOGGLE.isEmpty() ? ""
                : Html.render("toggle.html", Map.of("toggleUrl", base + "/toggle"));
        return Html.render("row.html", Map.of("cells", cells.toString(), "editUrl", base + "/edit",
                "toggleForm", toggle, "deleteUrl", base + "/delete", "question", Entity.DELETE_QUESTION));
    }

    // ------------------------------------------------ проверка данных формы

    private static boolean valid(Field f, String v) {
        return switch (f.kind()) {
            case "text" -> v.length() >= f.min() && v.length() <= f.max();
            case "url" -> v.length() <= f.max() && isWebAddress(v);
            case "date" -> isDate(v);
            case "int" -> v.matches("[0-9]{1,9}") && Integer.parseInt(v) >= f.min()
                    && Integer.parseInt(v) <= f.max();
            case "select" -> f.options().contains(v);
            default -> true;
        };
    }

    private static boolean isDate(String v) {
        try {
            LocalDate.parse(v);
            return true;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    private static boolean isWebAddress(String v) {
        try {
            URI uri = new URI(v);
            return ("http".equals(uri.getScheme()) || "https".equals(uri.getScheme()))
                    && uri.getHost() != null;
        } catch (java.net.URISyntaxException e) {
            return false;
        }
    }

    /** Общая для добавления и редактирования проверка полей формы. */
    private Form readForm(Ctx c) {
        Map<String, String> values = new LinkedHashMap<>();
        for (Field f : Entity.FIELDS) {
            String v = c.form(f.name()).trim();
            if (f.kind().equals("check")) {
                v = v.equals("1") ? "1" : "0";
            } else if (f.kind().equals("select") && !c.form.containsKey(f.name())) {
                v = f.options().get(0);
            }
            if (!valid(f, v)) {
                return new Form(null, f.error());
            }
            values.put(f.name(), v);
        }
        return new Form(values, null);
    }

    /** Загружает запись по номеру, только если она принадлежит текущему пользователю. */
    private Map<String, String> findOwn(Ctx c, long id) {
        Map<String, String> row = items.find(id);
        if (row == null || !row.get("user_id").equals(c.userId())) {
            throw new NotFound();
        }
        return row;
    }

    // ------------------------------------------- добавление, правка, удаление

    private String fieldsHtml(Map<String, String> values, boolean adding) {
        StringBuilder sb = new StringBuilder();
        for (Field f : Entity.FIELDS) {
            if (adding && !f.onAdd()) {
                continue;
            }
            String label = Html.esc(f.label());
            String name = Html.esc(f.name());
            String v = Html.esc(values.getOrDefault(f.name(), ""));
            switch (f.kind()) {
                case "select" -> {
                    sb.append("    <label>").append(label).append("\n      <select name=\"").append(name)
                            .append("\" required>\n");
                    for (String o : f.options()) {
                        sb.append("        <option value=\"").append(Html.esc(o)).append("\"")
                                .append(o.equals(values.get(f.name())) ? " selected" : "").append(">")
                                .append(Html.esc(o)).append("</option>\n");
                    }
                    sb.append("      </select>\n    </label>\n");
                }
                case "check" -> sb.append("    <label class=\"check\">\n      <input type=\"checkbox\" name=\"")
                        .append(name).append("\" value=\"1\"")
                        .append("1".equals(values.get(f.name())) ? " checked" : "").append(">\n      ")
                        .append(label).append("\n    </label>\n");
                default -> {
                    String type = f.kind().equals("int") ? "number" : f.kind().equals("text") ? "text" : f.kind();
                    String limits = f.kind().equals("int")
                            ? " min=\"" + f.min() + "\" max=\"" + f.max() + "\""
                            : f.kind().equals("date") ? "" : " maxlength=\"" + f.max() + "\"";
                    String hint = f.kind().equals("url") ? " placeholder=\"https://\"" : "";
                    sb.append("    <label>").append(label).append("\n      <input type=\"").append(type)
                            .append("\" name=\"").append(name).append("\" required").append(limits)
                            .append(hint).append(" value=\"").append(v).append("\">\n    </label>\n");
                }
            }
        }
        return sb.toString();
    }

    private void add(Ctx c) throws IOException {
        if (!c.requireLogin()) {
            return;
        }
        if (c.isPost()) {
            Form form = readForm(c);
            if (form.error() == null) {
                form.values().put("user_id", c.userId());
                items.insert(form.values());
                c.redirect(Entity.URL);
                return;
            }
            c.flash(form.error(), "error");
        }
        Map<String, String> shown = new LinkedHashMap<>();
        for (Field f : Entity.FIELDS) {
            shown.put(f.name(), f.kind().equals("date") ? LocalDate.now().toString() : "");
        }
        if (c.isPost()) {
            shown.putAll(c.form);
        }
        c.page(Entity.NEW_TITLE, Html.render("add.html", Map.of("title", Entity.NEW_TITLE,
                "fields", fieldsHtml(shown, true), "backUrl", Entity.URL)));
    }

    private void edit(Ctx c, long id) throws IOException {
        if (!c.requireLogin()) {
            return;
        }
        Map<String, String> row = findOwn(c, id);
        if (c.isPost()) {
            Form form = readForm(c);
            if (form.error() == null) {
                items.update(id, form.values());
                c.redirect(Entity.URL);
                return;
            }
            c.flash(form.error(), "error");
            row = c.form;
        }
        c.page(Entity.EDIT_TITLE, Html.render("edit.html", Map.of("title", Entity.EDIT_TITLE,
                "fields", fieldsHtml(row, false), "backUrl", Entity.URL)));
    }

    private void delete(Ctx c, long id) throws IOException {
        if (!c.isPost()) {
            c.text(405, "Метод не разрешён");
            return;
        }
        if (!c.requireLogin()) {
            return;
        }
        findOwn(c, id);
        items.delete(id);
        c.redirect(Entity.URL);
    }

    /** Переключает отметку записи (статус, «куплен», «возвращён»). */
    private void toggle(Ctx c, long id) throws IOException {
        if (Entity.TOGGLE.isEmpty()) {
            throw new NotFound();
        }
        if (!c.isPost()) {
            c.text(405, "Метод не разрешён");
            return;
        }
        if (!c.requireLogin()) {
            return;
        }
        Map<String, String> row = findOwn(c, id);
        Field f = Entity.field(Entity.TOGGLE);
        List<String> pair = f.kind().equals("check") ? List.of("0", "1") : f.options();
        String next = row.get(f.name()).equals(pair.get(1)) ? pair.get(0) : pair.get(1);
        items.update(id, Map.of(f.name(), next));
        c.redirect(Entity.URL);
    }
}
