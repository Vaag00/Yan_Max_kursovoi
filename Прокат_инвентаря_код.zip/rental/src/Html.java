import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Простой шаблонизатор. В HTML-файлах из каталога templates выражение
 * {{имя}} заменяется значением с экранированием специальных символов,
 * а {{{имя}}} – готовым HTML-фрагментом без экранирования.
 */
public final class Html {
    private static final Pattern PLACEHOLDER = Pattern.compile("\\{\\{\\{(\\w+)\\}\\}\\}|\\{\\{(\\w+)\\}\\}");

    private Html() {
    }

    /** Экранирует символы, имеющие особый смысл в HTML (защита от XSS). */
    public static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }

    /** Читает шаблон из файла и подставляет значения за один проход. */
    public static String render(String name, Map<String, String> vars) {
        String template;
        try {
            template = Files.readString(Path.of("templates", name), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        Matcher m = PLACEHOLDER.matcher(template);
        StringBuilder out = new StringBuilder();
        while (m.find()) {
            String raw = m.group(1);
            String key = raw != null ? raw : m.group(2);
            String value = vars.getOrDefault(key, "");
            m.appendReplacement(out, Matcher.quoteReplacement(raw != null ? value : esc(value)));
        }
        m.appendTail(out);
        return out.toString();
    }
}
