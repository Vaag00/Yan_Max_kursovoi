import java.util.ArrayList;
import java.util.List;

/** Сессия пользователя: номер вошедшего пользователя и одноразовые сообщения. */
public class Session {
    public Long userId;
    public final List<String[]> flashes = new ArrayList<>();
}
