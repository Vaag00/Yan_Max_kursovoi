import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Таблица реляционной базы данных H2. База хранится в каталоге data
 * (файл coursework.mv.db) и подключается через интерфейс JDBC.
 * Все запросы к базе выполняются через PreparedStatement.
 */
public class Table {
    private static final Map<String, Connection> CONNECTIONS = new HashMap<>();
    private final Connection db;
    private final String name;
    private final List<String> columns;

    public Table(String name, List<String> columns) {
        this.name = name;
        this.columns = columns;
        this.db = connect();
        StringBuilder sql = new StringBuilder("CREATE TABLE IF NOT EXISTS \"" + name
                + "\" (\"id\" BIGINT AUTO_INCREMENT PRIMARY KEY");
        for (String column : columns) {
            if (column.equals("id")) {
                continue;
            }
            String type = column.equals("user_id") ? "BIGINT NOT NULL"
                    : column.equals("login") ? "VARCHAR(30) NOT NULL UNIQUE"
                    : "VARCHAR(1000) NOT NULL";
            sql.append(", \"").append(column).append("\" ").append(type);
        }
        if (columns.contains("user_id")) {
            sql.append(", FOREIGN KEY (\"user_id\") REFERENCES \"users\"(\"id\") ON DELETE CASCADE");
        }
        sql.append(")");
        execute(sql.toString());
    }

    private static synchronized Connection connect() {
        try {
            Path dir = Path.of(System.getProperty("data.dir", "data")).toAbsolutePath();
            Files.createDirectories(dir);
            String url = "jdbc:h2:file:" + dir.resolve("coursework");
            Connection c = CONNECTIONS.get(url);
            if (c == null) {
                c = DriverManager.getConnection(url, "sa", "");
                CONNECTIONS.put(url, c);
            }
            return c;
        } catch (Exception e) {
            throw new IllegalStateException("Не удалось подключиться к базе данных", e);
        }
    }

    private void execute(String sql) {
        synchronized (db) {
            try (Statement st = db.createStatement()) {
                st.execute(sql);
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /** Выполняет SELECT с условием WHERE и возвращает записи, упорядоченные по номеру. */
    public List<Map<String, String>> select(String where, Object... params) {
        String sql = "SELECT * FROM \"" + name + "\"" + (where.isEmpty() ? "" : " WHERE " + where)
                + " ORDER BY \"id\"";
        synchronized (db) {
            try (PreparedStatement ps = db.prepareStatement(sql)) {
                for (int i = 0; i < params.length; i++) {
                    ps.setObject(i + 1, params[i]);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    ResultSetMetaData meta = rs.getMetaData();
                    List<Map<String, String>> rows = new ArrayList<>();
                    while (rs.next()) {
                        Map<String, String> row = new LinkedHashMap<>();
                        for (int i = 1; i <= meta.getColumnCount(); i++) {
                            row.put(meta.getColumnLabel(i), rs.getString(i));
                        }
                        rows.add(row);
                    }
                    return rows;
                }
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /** Все записи таблицы. */
    public List<Map<String, String>> all() {
        return select("");
    }

    /** Запись по номеру или null, если такой записи нет. */
    public Map<String, String> find(long id) {
        List<Map<String, String>> rows = select("\"id\" = ?", id);
        return rows.isEmpty() ? null : rows.get(0);
    }

    /** Добавляет запись (INSERT) и возвращает присвоенный ей номер. */
    public long insert(Map<String, String> values) {
        List<String> names = new ArrayList<>();
        for (String column : columns) {
            if (!column.equals("id")) {
                names.add(column);
            }
        }
        StringBuilder sql = new StringBuilder("INSERT INTO \"" + name + "\" (");
        StringBuilder marks = new StringBuilder();
        for (int i = 0; i < names.size(); i++) {
            sql.append(i > 0 ? ", " : "").append("\"").append(names.get(i)).append("\"");
            marks.append(i > 0 ? ", ?" : "?");
        }
        sql.append(") VALUES (").append(marks).append(")");
        synchronized (db) {
            try (PreparedStatement ps = db.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS)) {
                for (int i = 0; i < names.size(); i++) {
                    ps.setString(i + 1, values.getOrDefault(names.get(i), ""));
                }
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    return keys.getLong(1);
                }
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /** Обновляет указанные поля записи (UPDATE). */
    public void update(long id, Map<String, String> changes) {
        List<String> names = new ArrayList<>();
        for (String column : changes.keySet()) {
            if (columns.contains(column) && !column.equals("id")) {
                names.add(column);
            }
        }
        if (names.isEmpty()) {
            return;
        }
        StringBuilder sql = new StringBuilder("UPDATE \"" + name + "\" SET ");
        for (int i = 0; i < names.size(); i++) {
            sql.append(i > 0 ? ", " : "").append("\"").append(names.get(i)).append("\" = ?");
        }
        sql.append(" WHERE \"id\" = ?");
        synchronized (db) {
            try (PreparedStatement ps = db.prepareStatement(sql.toString())) {
                for (int i = 0; i < names.size(); i++) {
                    ps.setString(i + 1, changes.get(names.get(i)));
                }
                ps.setLong(names.size() + 1, id);
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        }
    }

    /** Удаляет запись по номеру (DELETE). */
    public void delete(long id) {
        synchronized (db) {
            try (PreparedStatement ps = db.prepareStatement("DELETE FROM \"" + name + "\" WHERE \"id\" = ?")) {
                ps.setLong(1, id);
                ps.executeUpdate();
            } catch (SQLException e) {
                throw new IllegalStateException(e);
            }
        }
    }
}
