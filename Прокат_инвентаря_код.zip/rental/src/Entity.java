import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;

/** Описание сущности приложения «Прокат спортивного инвентаря»: таблица, адреса, надписи и поля. */
public final class Entity {
    public static final String TABLE = "rental_items";
    public static final String URL = "/items";
    public static final String LIST_TEMPLATE = "items.html";
    public static final String LIST_TITLE = "Мой инвентарь";
    public static final String NEW_TITLE = "Новый инвентарь";
    public static final String EDIT_TITLE = "Редактирование инвентаря";
    public static final String EMPTY_TEXT = "Инвентаря пока нет.";
    public static final String DELETE_QUESTION = "Удалить позицию?";
    /** Поле, по которому работает фильтр списка (пустая строка – фильтра нет). */
    public static final String FILTER = "item_type";
    public static final String FILTER_LABEL = "Вид инвентаря";
    public static final String FILTER_ALL = "Все виды";
    /** Поле, значение которого переключается кнопкой «Отметить» (может быть пустым). */
    public static final String TOGGLE = "";
    public static final DateTimeFormatter RU_DATE = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    public static final List<Field> FIELDS = List.of(
            new Field("name", "Название", "Название", "text",
                    List.of(), 1, 100, "Название: от 1 до 100 символов.", true),
            new Field("item_type", "Вид", "Вид", "select",
                    List.of("Велосипед", "Лыжи", "Коньки", "Самокат"), 0, 0, "Выберите вид инвентаря из списка.", true),
            new Field("price_per_hour", "Цена за час, ₽", "Цена за час, ₽", "int",
                    List.of(), 1, 100000, "Цена за час — целое число рублей от 1 до 100 000.", true),
            new Field("status", "Статус", "Статус", "select",
                    List.of("Свободен", "В прокате", "На ремонте"), 0, 0, "Выберите статус из списка.", true));

    private Entity() {
    }

    /** Названия столбцов таблицы: номер, владелец и поля записи. */
    public static List<String> columns() {
        return List.of("id", "user_id", "name", "item_type", "price_per_hour", "status");
    }

    /** Поле по имени или null. */
    public static Field field(String name) {
        for (Field f : FIELDS) {
            if (f.name().equals(name)) {
                return f;
            }
        }
        return null;
    }

    private static long id(Map<String, String> row) {
        return Long.parseLong(row.get("id"));
    }

    /** Порядок записей в списке. */
    public static int compare(Map<String, String> a, Map<String, String> b) {
        return Long.compare(id(b), id(a));
    }
}
