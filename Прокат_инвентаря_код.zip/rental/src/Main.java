import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;

/** Точка входа: запускает встроенный HTTP-сервер JDK. */
public class Main {
    public static void main(String[] args) throws IOException {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress("127.0.0.1", port), 0);
        server.createContext("/", new App());
        server.setExecutor(Executors.newFixedThreadPool(8));
        server.start();
        System.out.println("Приложение запущено: http://127.0.0.1:" + port);
    }
}
