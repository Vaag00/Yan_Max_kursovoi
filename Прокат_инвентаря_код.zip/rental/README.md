# Прокат спортивного инвентаря

Веб-приложение на Java: встроенный HTTP-сервер JDK, HTML-шаблоны, база данных H2 (JDBC).
Нужен JDK 17 или новее; драйвер БД лежит в папке lib.

## Запуск

    javac -encoding UTF-8 -cp lib/h2-2.2.224.jar -d out src/*.java
    java -cp out:lib/h2-2.2.224.jar Main            # http://127.0.0.1:8080  (порт можно указать: java -cp out Main 9000)

Или запустите run.sh (Linux/macOS) / run.bat (Windows).

## Проверка

    sh test.sh                   # автоматические проверки (класс test/Tests.java)

## Структура

- src/ – исходный код (Main, App, Entity, Field, Table, Passwords, Html, Session)
- templates/ – HTML-шаблоны ({{имя}} – значение с экранированием, {{{имя}}} – готовый фрагмент HTML)
- static/style.css – оформление
- lib/ – драйвер и движок базы данных H2
- data/ – файл базы данных coursework.mv.db с таблицами users и rental_items (создаётся при первом запуске)
